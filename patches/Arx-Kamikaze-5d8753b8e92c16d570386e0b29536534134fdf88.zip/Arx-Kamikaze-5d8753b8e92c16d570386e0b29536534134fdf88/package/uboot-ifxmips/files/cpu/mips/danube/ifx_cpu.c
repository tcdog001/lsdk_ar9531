
#define IFX_CPU_RESET					\
{	*DANUBE_RCU_RST_REQ |=1<<30;			\
}

