
#define IFX_ETH_INITIALIZE_EXTERN	extern int danube_switch_initialize(bd_t *);
#define IFX_ETH_INITIALIZE(bd_t)	danube_switch_initialize(bd_t);

