#ifdef __linux__
#include_next <byteswap.h>
#endif
